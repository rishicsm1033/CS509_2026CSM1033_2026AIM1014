#include <iostream>
#include <vector>
#include <queue>
using namespace std;

void bfsAdjList(vector<vector<int>>& adj, int v)
{
    int n = adj.size();

    vector<bool> visited(n, false);
    vector<int> distance(n, -1);

    queue<int> que;

    que.push(v);
    visited[v] = true;
    distance[v] = 0;

    cout << "Algorithm: BFS" << endl;
    cout << "Source: " << v << endl;

    cout << "Traversal: ";

    while(!que.empty())
    {
        int currNode = que.front();
        que.pop();

        cout << currNode << " ";

        // Visit all neighbours directly
        for(int neighbor : adj[currNode])
        {
            if(!visited[neighbor])
            {
                visited[neighbor] = true;
                distance[neighbor] = distance[currNode] + 1;

                que.push(neighbor);
            }
        }
    }

    cout << endl;

    // Print distances
    cout << "Distances:" << endl;

    for(int i = 0; i < n; i++)
    {
        cout << i << " " << distance[i] << endl;
    }
}