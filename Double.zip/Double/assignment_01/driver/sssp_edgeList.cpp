#include <iostream>
#include <vector>
#include <queue>
#include <climits>
#include <functional>
using namespace std;
void ssspath(const vector<vector<pair<int, int>>>& adj,int nodes,int start_node)
{
    // Check source vertex
    if (start_node < 0 || start_node >= nodes)
    {
        cout << "[ERROR] Invalid source vertex." << endl;
        return;
    }
    // Distance from source to every vertex
    vector<int> dist(nodes, INT_MAX);
    // Min priority queue
    // pair = {distance, vertex}
    priority_queue<pair<int, int>,vector<pair<int, int>>, greater<pair<int, int>>> pq;
    // Distance from source to itself is 0
    dist[start_node] = 0;
    pq.push({0, start_node});
    while (!pq.empty())
    {
        int curr_dist = pq.top().first;
        int u = pq.top().second;
        pq.pop();
        // Ignore an old entry
        if (curr_dist > dist[u])
        {
            continue;
        }
        // Visit all neighbours of u
        for (auto edge : adj[u])
        {
            int v = edge.first;
            int weight = edge.second;
            // Relaxation
            if (dist[u] != INT_MAX &&
                dist[u] + weight < dist[v])
            {
                dist[v] = dist[u] + weight;

                pq.push({dist[v], v});
            }
        }
    }
    // Print result
    cout << "Algorithm: SSSP" << endl;
    cout << "Source: " << start_node << endl;
    cout << "Vertex\tDistance" << endl;
    for (int i = 0; i < nodes; i++)
    {
        cout << i << "\t";
        if (dist[i] == INT_MAX)
        {
            cout << "INF";
        }
        else
        {
            cout << dist[i];
        }
        cout << endl;
    }
}
