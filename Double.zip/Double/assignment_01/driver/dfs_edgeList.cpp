#include <iostream>
#include <vector>
#include <stack>
#include <chrono>

using namespace std;

void dfsAdjList(const vector<vector<int>>& adj, int V, int source)
{
    vector<bool> visited(V, false);
    stack<int> s;

    s.push(source);

    cout << "Algorithm: DFS" << endl;
    cout << "Source: " << source << endl;
    cout << "Traversal: ";

    while (!s.empty())
    {
        int curr = s.top();
        s.pop();

        if (visited[curr])
            continue;

        visited[curr] = true;

        cout << curr << " ";

        /*
         * Push neighbours in reverse order so that the first
         * neighbour in the input adjacency list is visited first.
         */
        for (int i = adj[curr].size() - 1; i >= 0; i--)
        {
            int neighbour = adj[curr][i];

            if (!visited[neighbour])
            {
                s.push(neighbour);
            }
        }
    }

    cout << endl;
}