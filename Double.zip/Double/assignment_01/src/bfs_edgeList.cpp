#include <iostream>
#include <vector>
#include <chrono>
#include <string>
using namespace std;

void bfsAdjList(vector<vector<int>>& adj, int v);

int main()
{
    int nodes, edges;

    cin >> nodes >> edges;

    // Adjacency list
    vector<vector<int>> adj(nodes);

    // Read adjacency-list input
    for(int i = 0; i < nodes; i++)
    {
        int u, degree;

        cin >> u >> degree;

        for(int j = 0; j < degree; j++)
        {
            int neighbor;
            cin >> neighbor;

            adj[u].push_back(neighbor);
        }
    }

    int v;

    cin  >> v;

    // Start timer
    auto start = chrono::high_resolution_clock::now();

    // BFS
    bfsAdjList(adj, v);

    // End timer
    auto end = chrono::high_resolution_clock::now();

    double time =
        chrono::duration_cast<chrono::microseconds>(end - start).count()
        / 1000.0;

    cout << endl;
    cout << "========================================" << endl;
    cout << "|| Execution time : " << time << " ms       ||" << endl;
    cout << "========================================" << endl;

    return 0;
}