#include <iostream>
#include <vector>
#include <string>
#include <chrono>

using namespace std;

void dfsAdjList(const vector<vector<int>>& adj, int V, int source);

int main()
{
    int V, E;

    cin >> V >> E;

    vector<vector<int>> adj(V);

    // Read adjacency-list representation
    for (int i = 0; i < V; i++)
    {
        int u, degree;

        cin >> u >> degree;

        for (int j = 0; j < degree; j++)
        {
            int neighbour;
            cin >> neighbour;

            adj[u].push_back(neighbour);
        }
    }

    // Read SOURCE s
    int source;

    cin >>  source;

    // Start timer
    auto start = chrono::high_resolution_clock::now();

    dfsAdjList(adj, V, source);

    auto end = chrono::high_resolution_clock::now();

    double time =
        chrono::duration_cast<chrono::microseconds>(
            end - start
        ).count() / 1000.0;

    cout << "Execution time: " << time << " ms" << endl;

    return 0;
}