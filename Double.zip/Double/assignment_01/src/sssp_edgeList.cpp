#include <iostream>
#include <vector>
#include <string>
#include <chrono>

using namespace std;

void ssspath(const vector<vector<pair<int, int>>>& adj,
             int nodes,
             int start_node);

int main()
{
    int nodes, edges;

    // Read V E
    cin >> nodes >> edges;

    // Adjacency list
    // adj[u] contains {neighbour, weight}
    vector<vector<pair<int, int>>> adj(nodes);

    // Read:
    // u degree neighbour1 weight1 neighbour2 weight2 ...
    for (int i = 0; i < nodes; i++)
    {
        int u, degree;

        cin >> u >> degree;

        for (int j = 0; j < degree; j++)
        {
            int neighbour, weight;

            cin >> neighbour >> weight;

            adj[u].push_back({neighbour, weight});
        }
    }

    // Read SOURCE s
    
    int source;

    cin >> source;

    // Start timer
    auto start = chrono::high_resolution_clock::now();

    ssspath(adj, nodes, source);

    // End timer
    auto end = chrono::high_resolution_clock::now();

    double time =
        chrono::duration_cast<chrono::microseconds>(
            end - start
        ).count() / 1000.0;

    cout << "Execution time: " << time << " ms" << endl;

    return 0;
}
