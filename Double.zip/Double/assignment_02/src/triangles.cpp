#include <iostream>
#include <vector>
#include <chrono>
#include <algorithm>
#include "edge_list.h"
using namespace std;
int triangleCount(vector<int>& row_ptr, vector<int>& col, int v, int e);
int main()
{
    int v, e;
    cout << "Enter the no.of vertices : ";
    cin >> v;
    cout << "Enter the no.of Edges : ";
    cin >> e;
    vector<edgeList> edges(e);
    cout << "Enter the edges : " << endl;
    for(int i = 0; i < e; i++)
    {
        cin >> edges[i].src>> edges[i].dest>> edges[i].weight;
    }
    // Adjacency list
    vector<vector<int>> adj(v);
    // Build adjacency list
    for(int i = 0; i < e; i++)
    {
        int u = edges[i].src;
        int w = edges[i].dest;
        // Undirected graph
        adj[u].push_back(w);
        adj[w].push_back(u);
    }
    // Sort neighbours
    for(int i = 0; i < v; i++)
    {
        sort(adj[i].begin(), adj[i].end());
    }
    // Build CSR
    vector<int> row_ptr(v + 1, 0);
    vector<int> col;
    // Calculate row_ptr
    for(int i = 0; i < v; i++)
    {
        row_ptr[i + 1] = row_ptr[i] + adj[i].size();
    }
    // Calculate col
    for(int i = 0; i < v; i++)
    {
        for(int neighbour : adj[i])
        {
            col.push_back(neighbour);
        }
    }
    cout << "row_ptr : ";
    for(int x : row_ptr)
    {
        cout << x << " ";
    }
    cout << endl;
    cout << "col : ";
    for(int x : col)
    {
        cout << x << " ";
    }
    cout << endl;
    auto start = chrono::high_resolution_clock::now();
    int result = triangleCount(row_ptr, col, v, e);
    auto end = chrono::high_resolution_clock::now();
    double time =chrono::duration_cast<chrono::microseconds>(end - start).count() / 1000.0;
    cout << "Triangle count : " << result << endl;
    cout << "========================================" << endl;
    cout << "|| Runtime : " << time << " ms ||" << endl;
    return 0;
}